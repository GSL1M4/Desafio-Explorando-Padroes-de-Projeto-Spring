package com.home.explorandopadroesprojetospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExplorandoPadroesProjetoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExplorandoPadroesProjetoSpringApplication.class, args);
	}

}
